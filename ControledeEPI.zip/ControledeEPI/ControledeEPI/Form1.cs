﻿using ControledeEPI.Resources;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControledeEPI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            Pessoa pessoa = new Pessoa();
            List<Pessoa> pessoas = new List<Pessoa>();
            dgvPessoa.DataSource = pessoas;
            btnEditar.Enabled = false;
            btnExcluir.Enabled = false;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            try
            {
                Pessoa pessoa = new Pessoa();
                DateTime dataEntrega;
                DateTime dataVencimento;

                if (!DateTime.TryParse(txtEntrega.Text, out dataEntrega) ||
                !DateTime.TryParse(txtVencimento.Text, out dataVencimento))
                {
                    // Se a conversão falhar para qualquer uma das datas, exiba uma mensagem de erro
                    MessageBox.Show("Formato de data inválido! Por favor, insira uma data válida.", "Erro de formato de data", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (pessoa.RegistroRepetido(txtMatricula.Text, txtEPI.Text, dataEntrega, dataVencimento) == true)                  
                {
                    MessageBox.Show("Pessoa já existe em nossa base de dados!", "Registro Repetido", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtMatricula.Text = "";
                    txtEPI.Text = "";
                    dataEntrega = DateTime.Now;
                    dataVencimento = DateTime.Now;
                    this.txtMatricula.Focus();
                    return;
                }
                else
                {
                    pessoa.Inserir(txtMatricula.Text, txtEPI.Text, dataEntrega, dataVencimento);
                    MessageBox.Show("Pessoa inserida com sucesso!", "Inserção", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    List<Pessoa> pessoas = pessoa.listapessoa();
                    dgvPessoa.DataSource = pessoas;
                    txtMatricula.Text = "";
                    txtEPI.Text = "";
                    dataEntrega = DateTime.Now;
                    dataVencimento = DateTime.Now;
                    this.txtMatricula.Focus();
                }
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            btnEditar.Enabled = true;
            btnExcluir.Enabled = true;
            try
            {
                int id = Convert.ToInt32(txtId.Text.Trim());
                Pessoa pessoa = new Pessoa();
                DateTime dataEntrega;
                DateTime dataVencimento;
                pessoa.Localizar(id);
                txtMatricula.Text = pessoa.matricula;
                txtEPI.Text = pessoa.EPI;
                dataEntrega = DateTime.Now;
                dataVencimento = DateTime.Now;
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text.Trim());
                Pessoa pessoa = new Pessoa();
                DateTime dataEntrega;
                DateTime dataVencimento;

                if (!DateTime.TryParse(txtEntrega.Text, out dataEntrega) ||
                !DateTime.TryParse(txtVencimento.Text, out dataVencimento))
                {
                    // Se a conversão falhar para qualquer uma das datas, exiba uma mensagem de erro
                    MessageBox.Show("Formato de data inválido! Por favor, insira uma data válida.", "Erro de formato de data", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                pessoa.Atualizar(id, txtMatricula.Text, txtEPI.Text, dataEntrega, dataVencimento);
                MessageBox.Show("Pessoa atualizada com sucesso!", "Atualização", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Pessoa> pessoas = pessoa.listapessoa();
                dgvPessoa.DataSource = pessoas;
                txtId.Text = "";
                txtMatricula.Text = "";
                txtEPI.Text = "";
                dataEntrega = DateTime.Now;
                dataVencimento = DateTime.Now;
                this.txtMatricula.Focus();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text.Trim());
                Pessoa pessoa = new Pessoa();
                DateTime dataEntrega;
                DateTime dataVencimento;

                if (!DateTime.TryParse(txtEntrega.Text, out dataEntrega) ||
                !DateTime.TryParse(txtVencimento.Text, out dataVencimento))
                {
                    // Se a conversão falhar para qualquer uma das datas, exiba uma mensagem de erro
                    MessageBox.Show("Formato de data inválido! Por favor, insira uma data válida.", "Erro de formato de data", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                pessoa.Excluir(id);
                MessageBox.Show("Pessoa excluída com sucesso!", "Exclusão", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Pessoa> pessoas = pessoa.listapessoa();
                dgvPessoa.DataSource = pessoas;
                txtId.Text = "";
                txtMatricula.Text = "";
                txtEPI.Text = "";
                dataEntrega = DateTime.Now;
                dataVencimento = DateTime.Now;
                this.txtMatricula.Focus();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvPessoa_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DateTime dataEntrega;
            DateTime dataVencimento;

            if (!DateTime.TryParse(txtEntrega.Text, out dataEntrega) ||
                !DateTime.TryParse(txtVencimento.Text, out dataVencimento))
            {
                // Se a conversão falhar para qualquer uma das datas, exiba uma mensagem de erro
                MessageBox.Show("Formato de data inválido! Por favor, insira uma data válida.", "Erro de formato de data", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvPessoa.Rows[e.RowIndex];
                this.dgvPessoa.Rows[e.RowIndex].Selected = true;
                txtId.Text = row.Cells[0].Value.ToString();
                txtMatricula.Text = row.Cells[1].Value.ToString();
                txtEPI.Text = row.Cells[2].Value.ToString();

                // Converter DateTime para string usando o formato desejado
                txtEntrega.Text = dataEntrega.ToString("yyyy-MM-dd");
                txtVencimento.Text = dataVencimento.ToString("yyyy-MM-dd");
            }

            btnEditar.Enabled = true;
            btnExcluir.Enabled = true;

        }
    }
}
