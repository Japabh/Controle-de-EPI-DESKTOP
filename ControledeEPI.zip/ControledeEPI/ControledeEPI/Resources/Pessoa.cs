﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ControledeEPI.Resources
{
    internal class Pessoa
    {
        public int id { get; set; }
        public string matricula { get; set; }
        public string EPI { get; set; }
        public  DateTime Data_Entrega { get; set; }
        public DateTime Data_Vencimento { get; set; }


        MySqlConnection con = new MySqlConnection("server=sql.freedb.tech;port=3306;database=freedb_multi2024;user=freedb_kenzo2024;password=m8mhcGQ?VfpaRg*");

        public List<Pessoa> listapessoa()
        {
            List<Pessoa> li = new List<Pessoa>();
            string sql = "SELECT * FROM pessoa";
            con.Open();
            MySqlCommand cmd = new MySqlCommand(sql, con);
            MySqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Pessoa p = new Pessoa();
                p.id = (int)dr["id"];
                p.matricula = dr["matricula"].ToString();
                p.EPI = dr["epi"].ToString();

                
                if (!dr.IsDBNull(dr.GetOrdinal("data_entrega")))
                {
                    p.Data_Entrega = dr.GetDateTime(dr.GetOrdinal("data_entrega"));
                }

                
                if (!dr.IsDBNull(dr.GetOrdinal("data_vencimento")))
                {
                    p.Data_Vencimento = dr.GetDateTime(dr.GetOrdinal("data_vencimento"));
                }
                else
                {
                    p.Data_Vencimento = DateTime.MinValue; 
                }

                li.Add(p);
            }
            dr.Close();
            con.Close();
            return li;
        }


        public void Inserir(string matricula, string EPI, DateTime Data_Entrega, DateTime Data_Vencimento)
        {
            string sql = "INSERT INTO pessoa(matricula,EPI,Data_Entrega,Data_Vencimento) VALUES ('" + matricula + "','" + EPI + "','" + Data_Entrega + "','" + Data_Vencimento + "')";
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            MySqlCommand cmd = new MySqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Atualizar(int id, string matricula, string EPI, DateTime Data_Entrega, DateTime Data_Vencimento)
        {
            string sql = "UPDATE pessoa SET matricula='" +   matricula + "',EPI='" + EPI + "' WHERE id='" + id + "'";
            con.Open();
            MySqlCommand cmd = new MySqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Excluir(int id)
        {
            string sql = "DELETE FROM pessoa WHERE id='" + id + "'";
            con.Open();
            MySqlCommand cmd = new MySqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Localizar(int id)
        {
            string sql = "SELECT * FROM pessoa WHERE id='" + id + "'";
            con.Open();
            MySqlCommand cmd = new MySqlCommand(sql, con);
            MySqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                matricula = dr["matricula"].ToString();
                EPI = dr["epi"].ToString();
            }
            dr.Close();
            con.Close();
        }

        public bool RegistroRepetido(string matricula, string EPI, DateTime Data_Entrega, DateTime Data_Vencimento)
        {
            string sql = "SELECT * FROM pessoa WHERE matricula='" +  matricula + "' AND EPI='" + EPI +"'";
            con.Open();
            MySqlCommand cmd = new MySqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            var result = cmd.ExecuteNonQuery();
            if (result != null)
            {
                return (int)result > 0;
            }
            con.Close();
            return false;
        }
    }
}

